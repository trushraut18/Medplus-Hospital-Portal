from django.shortcuts import render

def index(request):
	return render(request,'index.html',{})

def blog(request):
	return render(request,'blog.html',{})

def Patient(request):
	return render(request,'patient.html',{})
	
def Appointment(request):
	return render(request,'appointment.html',{})