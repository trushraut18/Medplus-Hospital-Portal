from django.db import models

SERVICE_CHOICES = (("NEUROLOGY","Neurology"),("CARDIOLOGY","Cardiology"),("DENTAL","Dental"),("OPHTHALMOLOGY","Ophthalmology"),("OTHER SERVICES","Other Services"))

class User(models.Model):
	name =  models.CharField(max_length = 100,null=True)
	email =  models.EmailField(max_length = 254,unique = True,null=True)
	phone = models.CharField(max_length = 15,null=True)
	password = models.CharField(max_length=40,null=True)

class Blog(models.Model):
    name = models.CharField(max_length=100)
    tagline = models.TextField(null=True, blank=True)
    img = models.ImageField(upload_to = 'static/images',default = None)
    body_text = models.TextField(null=True, blank=True)
    author = models.CharField(max_length=100,null=True, blank=True)

class Appointment(models.Model):
	first_name =  models.CharField(max_length = 50)
	last_name =  models.CharField(max_length = 50)
	service = models.CharField(max_length = 30,choices = SERVICE_CHOICES)
	phone = models.CharField(max_length = 15)
	date = models.DateField()
	time = models.TimeField()
	message = models.CharField(max_length = 500)

class Patient(models.Model):
	first_name =  models.CharField(max_length = 50)
	last_name =  models.CharField(max_length = 50)
	phone = models.CharField(max_length = 15)
	email =  models.EmailField(max_length = 254,unique = True)
	service = models.CharField(max_length = 30,choices = SERVICE_CHOICES)

class add_doctor(models.Model):
    first_name = models.CharField(max_length = 100)
    last_name = models.CharField(max_length = 100)
    designation = models.CharField(max_length = 200)

class add_services(models.Model):
    service_name = models.CharField(max_length = 100)
    information = models.CharField(max_length = 200)

class add_dept(models.Model):
    dept_name = models.CharField(max_length = 100)
    designation = models.CharField(max_length = 200)

class testimonials(models.Model):
    information = models.CharField(max_length = 200)
    person_name = models.CharField(max_length = 100)
    designation = models.CharField(max_length = 100)
