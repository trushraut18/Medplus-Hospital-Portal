from django.urls import path,include
from mediplusapp import views

urlpatterns =[
	path('',views.Index_view,name='index'),
	path('login/',views.Login_view,name ='login'),
	path('logout/',views.Logout_view,name='logout'),
	path('registration/',views.Registration_view,name='registration'),
	path('blog/',views.Blog_view,name='blog'),
	path('appointment/',views.Appointment_view,name='appointment'),
	path('register_user/',views.Register_user_view,name='register_user'),
	path('patient/',views.Patient_view,name='patient'),
    path('blog/add_blog/',views.Add_blog_view,name='add_blog'),

   path('add_doctor/',views.Add_doctors,name="add_doctor"),
   path('add_doc_list/',views.Add_dl,name="add_doc_list"),

   path('add_services/',views.Add_services,name="add_services"),
   path('service_list/',views.Add_serv,name="service_list"),

   path('add_dept/',views.Add_dept,name="add_dept"),
   path('dept_list/',views.Add_depts,name="dept_list"),

   path('testimonials/',views.Testimo,name="testimonials"),
   path('testimo_list/',views.Add_testimo,name="testimo_list"),
    
]
