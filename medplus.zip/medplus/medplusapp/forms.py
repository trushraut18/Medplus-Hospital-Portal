from django import forms
from mediplusapp.models import User,Blog,Patient,Appointment,add_doctor,add_services,add_dept,testimonials

class Registration_form(forms.ModelForm):
	def _init_(self,args,*kwargs):
		super(Registration_form,self)._init_(args,*kwargs)
		for field_name,field in self.fields.items():
			field.widget.attrs['class']='ggg'
		
	class Meta :
		model = User
		fields = "__all__"		

class Blog_form(forms.ModelForm):
	def __init__(self, *args, **kargs):
		super(Blog_form, self).__init__(*args, **kargs)
		for field_name, field in self.fields.items():
			# field.col_len= 'col-md-4'
			field.widget.attrs['class']='form-control'
	class Meta :
		model = Blog
		fields ="__all__"

class Appointment_form(forms.ModelForm):
	def _init_(self,args,*kwargs):
		super(Appointment_form,self)._init_(args,*kwargs)
		for field_name,field in self.fields.items():
			field.widget.attrs['class']='ggg'

	class Meta :
		model = Appointment
		fields ="__all__"
				
class Patient_form(forms.ModelForm):
	def _init_(self,args,*kwargs):
		super(Patient_form,self)._init_(args,*kwargs)
		for field_name,field in self.fields.items():
			field.widget.attrs['class']='ggg'

	class Meta :
		model = Patient
		fields ="__all__"
				

class Doctor_form(forms.ModelForm):
    def __init__(self, *args, **kargs):
        super(Doctor_form, self).__init__(*args, **kargs)
        for field_name, field in self.fields.items():
			# field.col_len= 'col-md-4'
            field.widget.attrs['class']='form-control'
    class Meta:
        model = add_doctor
        fields = "__all__"

class Services_form(forms.ModelForm):
    def __init__(self, *args, **kargs):
        super(Services_form, self).__init__(*args, **kargs)
        for field_name, field in self.fields.items():
			# field.col_len= 'col-md-4'
            field.widget.attrs['class']='form-control'
    class Meta:
        model = add_services
       	fields = "__all__"

class Dept_form(forms.ModelForm):
    def __init__(self, *args, **kargs):
        super(Dept_form, self).__init__(*args, **kargs)
        for field_name, field in self.fields.items():
			# field.col_len= 'col-md-4'
            field.widget.attrs['class']='form-control'
    class Meta:
        model = add_dept
        fields = "__all__"

class Testimo_form(forms.ModelForm):
    def __init__(self, *args, **kargs):
        super(Testimo_form, self).__init__(*args, **kargs)
        for field_name, field in self.fields.items():
			# field.col_len= 'col-md-4'
            field.widget.attrs['class']='form-control'
    class Meta:
        model = testimonials
        fields = "__all__"