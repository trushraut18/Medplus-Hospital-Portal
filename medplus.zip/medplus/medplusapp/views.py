from django.views.generic import TemplateView
from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from mediplusapp.forms import Registration_form,Appointment_form,Blog_form,Testimo_form,Doctor_form,Services_form,Dept_form
from django.contrib.auth import authenticate,logout
from .models import *
from django.contrib.sessions.models import Session
from django.contrib import messages


def Index_view(request):
	if request.session.has_key('is_logged'):
		return render(request,"index.html")
	else :
		return redirect('login')


def Login_view(request):
	if request.session.has_key('is_logged'):
		return render(request,"index.html")
    
	if request.method=="POST":
		email=request.POST.get('Email')
		password=request.POST.get('Password')
		try :
			data = User.objects.get(email=email, password=password)
			
		except :
			data = None
		if data:
			request.session['is_logged'] = True
			request.session['email'] = data.email
			request.session['name'] = data.name
			request.session['phone'] = data.phone
			request.session['password'] = data.password
			request.user = data
			return redirect('index')
		else :
			messages.error(request,"Invalid Email or Password")
			return redirect('login')
	else :	
		return render(request,"login.html")
		


def Logout_view(request):
    del request.session['is_logged']
    del request.session['email']
    del request.session['name']
    del request.session['phone']
    del request.session['password']
    logout(request)
    return render(request,'logout.html')

	
def Registration_view(request):
	form = Registration_form()
	if request.method == 'POST':
		form = Registration_form(request.POST)
		if form.is_valid():
			form.save()
			return HttpResponse('Success')
		else :
			return render(request,'registration.html',{'form' :form})
	else :
		return render(request,'registration.html',{'form' :form})	
    

def Register_user_view(request):
	if request.POST:
		name = request.POST.get('name')
		email = request.POST.get('email')
		phone = request.POST.get('phone')
		password = request.POST.get('password')

		obj = User(email=email,name=name,phone=phone,password=password)
		obj.save()

	return redirect('login')
    

def Blog_view(request):
	if request.session.has_key('is_logged'):
		Blogs = Blog.objects.all().order_by('-id')
		return render(request,'blog.html',{'Blogs':Blogs})
	else :
		return redirect('login')

	

def Add_blog_view(request):
	if request.session.has_key('is_logged'):
		form = Blog_form()
		if request.method == 'POST':
			form = Blog_form(request.POST,request.FILES)
			if form.is_valid():
				form.save()
				return redirect('blog')
			else :
				return render(request,'add_blog.html',{'form' :form})
		else :
			return render(request,'add_blog.html',{'form' :form})
	else :
		return redirect('login')

		
    

def Appointment_view(request):
	if request.session.has_key('is_logged'):
		appoint = Appointment.objects.all()
		return render(request,"appointment.html",{'Appointment':appoint})
	else :
		return redirect('login')

	
	

def Patient_view(request):
	if request.session.has_key('is_logged'):
		patients = Patient.objects.all()
		return render(request,"patient.html",{'patients':patients})
	else :
		return redirect('login')

	

def Add_doctors(request):
    
    
    form = Doctor_form()
    if request.method == 'POST':
        form = Doctor_form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse('Success')
        else:
            return render(request,"add_doctor.html",{'form':form})
    else:
        form = Doctor_form()
        return render(request, "add_doctor.html",{'form':form})

def Add_dl(request):
    all_doctors = add_doctor.objects.all()
    return render(request,'add_doc_list.html',{'doctor':all_doctors})


def Add_services(request): 
    form = Services_form()
    if request.method == 'POST':
        form = Services_form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse('Success')
        else:
            return render(request,"add_services.html",{'form':form})
    else:
        form = Services_form()
        return render(request, "add_services.html",{'form':form})

def Add_serv(request):
    all_serv = add_services.objects.all()
    return render(request,'service_list.html',{'service':all_serv})


def Add_dept(request):
    form = Dept_form()
    if request.method == 'POST':
        form = Dept_form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse('Success')
        else:
            return render(request,"add_dept.html",{'form':form})
    else:
        form = Dept_form()
        return render(request, "add_dept.html",{'form':form})

def Add_depts(request):
    all_depts = add_dept.objects.all()
    return render(request,'dept_list.html',{'dept':all_depts})

def Testimo(request):
    form = Testimo_form()
    if request.method == 'POST':
        form = Testimo_form(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse('Success')
        else:
            return render(request,"testimonials.html",{'form':form})
    else:
        form = Testimo_form()
        return render(request, "testimonials.html",{'form':form})

def Add_testimo(request):
    all_testimo = testimonials.objects.all()
    return render(request,'testimo_list.html',{'testm':all_testimo})



