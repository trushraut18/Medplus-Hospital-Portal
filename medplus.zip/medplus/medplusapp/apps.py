from django.apps import AppConfig


class MediplusappConfig(AppConfig):
    name = 'mediplusapp'
