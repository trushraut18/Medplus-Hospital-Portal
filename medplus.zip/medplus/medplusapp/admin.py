from django.contrib import admin

from .models import User,Blog,Appointment,Patient,add_doctor,add_services,add_dept,testimonials
class UserAdmin(admin.ModelAdmin):
	list_display = ('name','email','phone','password')

class BlogAdmin(admin.ModelAdmin):
	list_display =('name','tagline','img','body_text','author')

class AppointmentAdmin(admin.ModelAdmin):
	list_display = ('first_name','last_name','service','phone','time','message')

class PatientAdmin(admin.ModelAdmin):
	list_display = ('first_name','last_name','phone','email','service')

admin.site.register(User,UserAdmin)
admin.site.register(Blog,BlogAdmin)
admin.site.register(Appointment,AppointmentAdmin)
admin.site.register(Patient,PatientAdmin)


admin.site.register(add_doctor)
admin.site.register(add_services)
admin.site.register(add_dept)
admin.site.register(testimonials)